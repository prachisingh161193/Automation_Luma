package mainModules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Luma_Login {
	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
	public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
	public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
	public void signin(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Sign")).click();  
		driver.findElement(By.id("email")).sendKeys("kumaripuja2359@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("pass")).sendKeys("Family@143");
		Thread.sleep(2000);
		driver.findElement(By.id("send2")).click();
	}
	public static void main(String[] args) throws InterruptedException
{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\chromedriver.exe");
        WebDriver driver =new ChromeDriver();
        
        Luma_Login l= new  Luma_Login();
        
        l.url(driver);
        l.maximize(driver);
        l.cookies(driver);
        Thread.sleep(2000);
        l.signin(driver);

	}

}
