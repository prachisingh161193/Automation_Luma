package mainModules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Luma_ShopNewYoga_UsingFilters {

	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
public void newuser(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Create an")).click();
		driver.findElement(By.id("firstname")).sendKeys("Puja");
		//Thread.sleep(2000);
		driver.findElement(By.id("lastname")).sendKeys("Kumari");
		//Thread.sleep(2000);
		driver.findElement(By.id("email_address")).sendKeys("kumaripuja2359@gmail.com");
		//Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("Family@143");
		//Thread.sleep(2000);
		driver.findElement(By.id("password-confirmation")).sendKeys("Family@143");
	//	Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Create an")).click();
	}
public void signin(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Sign")).click();  
		driver.findElement(By.id("email")).sendKeys("kumaripuja2359@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("pass")).sendKeys("Family@143");
		Thread.sleep(2000);
		driver.findElement(By.id("send2")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@aria-label='store logo']//img")).click();
	}
	public void ShopNewYoga(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.xpath("//a[@aria-label='store logo']//img")).click();
		driver.findElement(By.xpath("//span[@class='action more button']")).click();
		driver.findElement(By.xpath("//div[normalize-space()='Size']")).click();
		driver.findElement(By.xpath("//a[@aria-label='L']//div[contains(@class,'swatch-option text')][normalize-space()='L']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[normalize-space()='Color']")).click();
		driver.findElement(By.xpath("//a[@aria-label='Green']//div[contains(@class,'swatch-option color')]")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("option-label-size-143-item-170")).click();
		driver.findElement(By.id("option-label-color-93-item-60")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li[1]//div[1]//div[1]//div[4]//div[1]//div[1]//form[1]//button[1]")).click();
		driver.findElement(By.xpath("//a[@class='action showcart']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[text()='Proceed to Checkout']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		Thread.sleep(5000);
	}
	/*public void ShippingAddress(WebDriver driver) throws InterruptedException
	{
        driver.findElement(By.id("QODAC1D")).sendKeys("Puja");
    	driver.findElement(By.id("WQJKFA6")).sendKeys("Kumari");
		 Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@name='company']")).sendKeys("IBM");
	
		driver.findElement(By.xpath("//input[@name='street[0]']")).sendKeys("House no- 19");
		driver.findElement(By.xpath("//input[@name='street[1]']")).sendKeys("SamyathiHouse, 2nd cross");
		driver.findElement(By.xpath("//input[@name='street[2]']")).sendKeys("SilkBoard");
		driver.findElement(By.xpath("//input[@name='city']")).sendKeys("Bangalore");
		driver.findElement(By.xpath("//input[@name='telephone']")).sendKeys("7415166957");
		 Thread.sleep(2000);
		driver.findElement(By.xpath("//span[text()='Next']")).click();
	}*/
	public void ReviewAndPayments(WebDriver driver) throws InterruptedException 
	{
		driver.findElement(By.xpath("//span[text()='Place Order']")).click();
		Thread.sleep(2000);
	}
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\chromedriver.exe");
        WebDriver driver =new ChromeDriver();
        
        Luma_ShopNewYoga_UsingFilters l= new  Luma_ShopNewYoga_UsingFilters();
 
        l.url(driver);
        l.maximize(driver);
        l.cookies(driver);
        Thread.sleep(2000);
        l.newuser(driver);
        Thread.sleep(2000);
        l.signin(driver);
        l.ShopNewYoga(driver);
       // l.ShippingAddress(driver);
        l.ReviewAndPayments(driver);
        System.out.println("your order number is: "+ driver.findElement(By.xpath("//a[@class='order-number']")).getText());
 
	}

}
