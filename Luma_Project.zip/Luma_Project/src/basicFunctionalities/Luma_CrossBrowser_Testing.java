package basicFunctionalities;

import java.util.Scanner;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class Luma_CrossBrowser_Testing {

WebDriver driver;
	
	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
public void newuser(WebDriver driver) throws InterruptedException
{
	driver.findElement(By.partialLinkText("Create an")).click();
	driver.findElement(By.id("firstname")).sendKeys("Puja");
	//Thread.sleep(2000);
	driver.findElement(By.id("lastname")).sendKeys("Kumari");
	//Thread.sleep(2000);
	driver.findElement(By.id("email_address")).sendKeys("kumaripuja2359@gmail.com");
	//Thread.sleep(2000);
	driver.findElement(By.id("password")).sendKeys("Family@143");
	//Thread.sleep(2000);
	driver.findElement(By.id("password-confirmation")).sendKeys("Family@143");
//	Thread.sleep(2000);
	driver.findElement(By.partialLinkText("Create an")).click();

}
public void signin(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Sign")).click();  
		driver.findElement(By.id("email")).sendKeys("kumaripuja2359@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("pass")).sendKeys("Family@143");
		Thread.sleep(2000);
		driver.findElement(By.id("send2")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@aria-label='store logo']//img")).click();
	}
public void welcomePujaKumari(WebDriver driver)
{
	 driver.findElement(By.xpath("//span[@aria-expanded='false']")).click();
}
public void signout(WebDriver driver)
{
	 driver.findElement(By.partialLinkText("Sign")).click();
}
private static final WebDriver Null = null;
	public static void main(String[] args) throws InterruptedException {
		Scanner s= new Scanner(System.in);
        System.out.println("Enter 1 for Google Chrome\nEnter 2 for MS_edge\nEnter 3 for MozillaFirefox");
        int input= s.nextInt();
        
        WebDriver driver= Null;
        
        switch(input)
        
        {
        case 1:
			System.out.println("**Google Chrome**");
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\Kunal\\Documents\\Automation\\chromedriver-win32\\chromedriver.exe");
			driver = new ChromeDriver();
			break;
		case 2:
			System.out.println("**MS_edge**");
			System.setProperty("webdriver.msedge.driver",
					"C:\\Users\\Kunal\\Documents\\Automation\\Browser Extension\\msedgedriver.exe");
			driver = new EdgeDriver();
			break;
		case 3:
			System.out.println("**Firfox**");
			System.setProperty("webdriver.gecko.driver",
					"C:\\Users\\Kunal\\Documents\\Automation\\Browser Extension\\geckodriver.exe");
			driver = new FirefoxDriver();
			break;

		default:
			System.out.println("Invalid Input");
		
        }
        
        //Create Object of Luma_P class
        Luma_CrossBrowser_Testing l= new  Luma_CrossBrowser_Testing();
		 l.url(driver);
        l.maximize(driver);
        l.cookies(driver);
       Thread.sleep(2000);
       l.newuser(driver);
        l.signin(driver);
       Thread.sleep(1000);
        l.welcomePujaKumari(driver);
       Thread.sleep(2000);
  	   l.signout(driver);
    	driver.close();
	}

}
