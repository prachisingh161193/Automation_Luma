package testNG;

import org.testng.annotations.Test;
import KDT_framework.OperationalClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class DDT_Luma {
	WebDriver driver;
	
	  @BeforeTest
	  public void beforeTest() 
	  {
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\chromedriver.exe");
		   driver= new ChromeDriver();
		   driver.manage().window().maximize();
		   driver.manage().deleteAllCookies();
	  }
  @Test(dataProvider = "dp")
  public void f(String email, String password) throws Exception 
  {
	  OperationalClass l= new OperationalClass();
	  l.url(driver);
      l.maximize(driver);
      l.cookies(driver);
      Thread.sleep(2000);
      l.email(driver, email);
      l.password(driver, password);
      Thread.sleep(2000);
      l.signinbutton(driver);
      Thread.sleep(2000);
      l.welcomeAdmin(driver);
      Thread.sleep(2000);
      l.signout(driver);
 }
  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "kumaripuja2359@gmail.com", "Family@143" },
      new Object[] { "manoj19@gmail.com", "Water@123" },
      new Object[] { "kusum23@gmail.com.com", "Target@0" },
      new Object[] { "kumaripuja2359@gmail.com", "Family@143" },
      new Object[] { "murali19@gmail.com", "Uturn@0" },
      new Object[] { "jamuna24@gmail.com.com", "boss@24" },
    };
  }
  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
