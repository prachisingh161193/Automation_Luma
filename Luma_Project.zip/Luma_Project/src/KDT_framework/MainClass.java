package KDT_framework;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainClass 
{
public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\chromedriver.exe");
        WebDriver driver= new ChromeDriver();
        Thread.sleep(2000);
        ReadExcelClass r= new ReadExcelClass();
        
	}

}
