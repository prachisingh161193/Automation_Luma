package basicfunctionalities;

public class Luma_CrossBrowser_Testing 
{
	public void url(WebDriver driver)
	{
		
	}
	

}
